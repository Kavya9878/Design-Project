#Reference from: 1. Hsieh, A. and Liu, H. (2020). Alexabot. [online] GitHub.com. Available at: https://github.com/yahsiuhsieh/alexabot.
import logging
import ask_sdk_core.utils as ask_utils

from ask_sdk_core.skill_builder import SkillBuilder
from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.dispatch_components import AbstractExceptionHandler
from ask_sdk_core.handler_input import HandlerInput

from ask_sdk_model import Response



import json
import os
import boto3

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

bucket_name = 'bucket_name'
ACCESS_KEY = 'XXXXXXXXXXXXXXXXXXXXXXXX'
SECRET_KEY = 'XXXXXXXXXXXXXXXXXXXXXXXX'

client = boto3.client("s3",
    amazon_access_key_id=ACCESS_KEY,
    amazon_secret_access_key=SECRET_KEY)
s3 = boto3.resource('s3')
bucket = s3.Bucket(bucket_name)

mqtt_pub = boto3.client('iot-data',amazon_access_key_id=ACCESS_KEY, amazon_secret_access_key=SECRET_KEY, region_name='us-east-1')


class LaunchRequestHandler(AbstractRequestHandler):
    """Handler for Skill Launch."""
    def can_handle(self, handler_input):

        return ask_utils.is_request_type("LaunchRequest")(handler_input)

    def handle(self, handler_input):
        speak_output = "Sure, what would you like to do today?"
        reprompt_text = "Sorry, can you repeat again?"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(reprompt_text)
                .response
        )
class MoveToKitchenHandler(AbstractRequestHandler):
    """Handler for Move to Kitchen Intent."""

    def can_handle(self, handler_input):
        return ask_utils.is_intent_name("MoveToKitchen")(handler_input)

    def handle(self, handler_input):
        speak_output = "Ok, moving to Kitchen"
        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )
class MoveToLivingRoomHandler(AbstractRequestHandler):
    """Handler for Move to Living Room Intent."""

    def can_handle(self, handler_input):
        return ask_utils.is_intent_name("MoveToLivingRoom")(handler_input)

    def handle(self, handler_input):
        speak_output = "Ok, moving to Living Room"
        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )


class MoveToBedroomHandler(AbstractRequestHandler):
    """Handler for Move to Bedroom Intent."""

    def can_handle(self, handler_input):
        return ask_utils.is_intent_name("MoveToBedroom")(handler_input)

    def handle(self, handler_input):
        speak_output = "Ok, moving to Bedroom"
        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )
    

class CatchingResponseIntentHandler(AbstractRequestHandler):
    """Handler for capturing the Response Intent."""
    def can_handle(self, handler_input):
        return ask_utils.is_intent_name("CatchingResponseIntent")(handler_input)

    def handle(self, handler_input):

        s = ''

        slots = handler_input.request_envelope.request.response.slots
        room = slots['room'].value; s = s+str(room)+",";
        person_name = slots['person_name'].value;   s = s+str(person_name);   
        speak_output = "No worries! I would send turtlebot3 to {person_name} to {room}".format(person_name=person_name, room=room)

        response = mqtt_pub.publish(
            topic='voice_commands_echobot',
            qos=0,
            payload = json.dumps({"position":str(room)})
            )

        file_name = "record_voice_commands.txt"
        client.put_object(Bucket=bucket_name, Key=file_name, Body=s)

        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )



class HelpIntentHandler(AbstractRequestHandler):
    """Handler for Help Intent."""
    def can_handle(self, handler_input):
        return ask_utils.is_intent_name("AMAZON.HelpIntent")(handler_input)

    def handle(self, handler_input):
        speak_output = "Hi! How can I help you today?"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )


class CancelOrStopIntentHandler(AbstractRequestHandler):
    """Single handler for Cancelling and Stopping the Intent."""
    def can_handle(self, handler_input):
        return (ask_utils.is_intent_name("AMAZON.CancelIntent")(handler_input) or
                ask_utils.is_intent_name("AMAZON.StopIntent")(handler_input))

    def handle(self, handler_input):
        speak_output = "Hope that was useful!. See you tmr!"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )


class SessionEndedRequestHandler(AbstractRequestHandler):
    """Handler for Session End."""
    def can_handle(self, handler_input):
        return ask_utils.is_request_type("SessionEndedRequest")(handler_input)

    def handle(self, handler_input):

        return handler_input.response_builder.response

class CatchErrorsHandler(AbstractExceptionHandler):

    def can_handle(self, handler_input, exception):
        return True

    def handle(self, handler_input, exception):
        logger.error(exception, exc_info=True)

        speak_output = "I am so sorry, I did not quite understand what you said. Can you repeat that please."

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )




sb = SkillBuilder()

sb.add_request_handler(LaunchRequestHandler())
sb.add_request_handler(MoveToKitchenHandler())
sb.add_request_handler(MoveToLivingRoomHandler())
sb.add_request_handler(MoveToBedroomHandler())
sb.add_request_handler(CatchingResponseIntentHandler())
sb.add_request_handler(HelpIntentHandler())
sb.add_request_handler(CancelOrStopIntentHandler())
sb.add_request_handler(SessionEndedRequestHandler())

sb.add_exception_handler(CatchErrorsHandler())

lambda_handler = sb.lambda_handler()