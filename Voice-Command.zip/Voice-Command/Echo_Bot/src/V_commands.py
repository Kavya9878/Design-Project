
import rospy
import roslib
import json
import time
import numpy as np
import paho.mqtt.client as mqtt

from echobot.srv import Command
from echobot.srv import CommandRequest
from echobot.srv import CommandResponse


Voice_COMMANDS_TOPIC   = "voice_commands_echobot"

MQTT_BROKER_URL  = "100.81.37.230"
MQTT_BROKER_PORT = 1883


def handle_message(client, msg):
    if msg.topic == Voice_COMMANDS_TOPIC:
        
        command_json = json.JSONDecoder().decode(str(msg.payload))
        position     = command_json["position"]
        
        rospy.wait_for_service("voice_commands")
        try:
            Commands_srv = rospy.ServiceProxy("voice_commands", Command)
            Commands_srv(position)
        except rospy.ServiceException as e:
            print("Service call failed: %s" % e)
                            
def on_connect(client, userdata, flags, rc):
    if(rc == 0):
        print("connection is okay, return code=0")
        client.subscribe(Voice_COMMANDS_TOPIC)
    else:
        print("Poor Connection, return code=", rc)


def on_message(client, userdata, msg):
    print(msg.topic + " " + str(msg.payload))
    handle_message(client, msg)


rospy.init_node('voice_command', anonymous=True)
client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

client.connect(MQTT_BROKER_URL, MQTT_BROKER_PORT)

try:
    client.loop_forever()
except KeyboardInterrupt:
    client.disconnect()