from launch import LaunchDescription
from launch_ros.actions import Node
 
def generate_launch_description():
    # Create launch actions
    start_reminder_checkin = Node(
            package='reminder_checkin',
            executable='reminder_checkin',
            name='reminder_checkin',
            #remappings=[('/original_topic', '/remapped_topic')],
            output="screen",
            emulate_tty=True)
    
    # Create Launch Description
    ld = LaunchDescription()
    ld.add_action(start_reminder_checkin)
    
    return ld
